# WebUtils
# Webware for Python
# See Docs/index.html

__all__ = ['HTMLForException', 'HTTPStatusCodes', 'HTMLTag', 'Funcs']


def InstallInWebKit(appServer):
    pass

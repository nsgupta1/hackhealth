from Testing.DebugPage import DebugPage


class Forward2Target(DebugPage):
    pass

from Testing.DebugPage import DebugPage


class Forward3Target(DebugPage):
    pass

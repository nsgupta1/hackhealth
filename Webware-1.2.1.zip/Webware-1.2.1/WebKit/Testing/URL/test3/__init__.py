from WebKit.URLParser import URLParameterParser
urlParserHook = URLParameterParser()

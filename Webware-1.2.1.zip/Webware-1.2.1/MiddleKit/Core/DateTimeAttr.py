from AnyDateTimeAttr import AnyDateTimeAttr


class DateTimeAttr(AnyDateTimeAttr):

    def __init__(self, attr):
        AnyDateTimeAttr.__init__(self, attr)

from Attr import Attr


class AnyDateTimeAttr(Attr):

    def __init__(self, attr):
        Attr.__init__(self, attr)

from SQLPythonGenerator import SQLPythonGenerator


class SQLitePythonGenerator(SQLPythonGenerator):
    pass

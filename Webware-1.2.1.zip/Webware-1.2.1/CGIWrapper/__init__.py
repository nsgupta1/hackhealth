"""CGIWrapper package

A Webware for Python plugin. See Docs/index.html.

"""


def InstallInWebKit(appServer):
    pass
